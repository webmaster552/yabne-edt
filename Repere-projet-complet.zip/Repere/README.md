# Repère

Application locale de suivi scolaire, connectée à ÉcoleDirecte en lecture seule. Espaces élève, parent (sélection des enfants autorisés) et professeur (classes et groupes autorisés).

## Démarrer

Voir **LISEZ-MOI.txt** pour l’installation et le partage. Node.js 22 ou plus récent est requis ; aucun paquet npm n’est nécessaire.

- Windows : `Demarrer-Repere.bat`.
- Mac : `Demarrer-Repere.command`.
- Linux : `bash Demarrer-Repere.sh`.
- Tous systèmes : `node start.mjs` ou `npm start`.

Le lanceur ouvre le navigateur. Laisser le terminal ouvert ; Ctrl+C arrête le serveur. `node start.mjs --no-open` démarre sans ouvrir le navigateur. `REPERE_PORT` permet de choisir un autre port local si nécessaire (les données du navigateur sont séparées par port).

Pour les conseils, les photos et les préparations, installer puis démarrer Ollama et télécharger les modèles `qwen3:1.7b`, `qwen3.5:4b` et `qwen2.5-coder:14b` avec `ollama pull NOM_DU_MODELE`. Les modèles ne sont pas inclus dans l’archive ; la première installation nécessite Internet, de l’espace disque et des ressources matérielles adaptées. Sans eux, les données scolaires et le classeur restent utilisables, mais pas les générations. Aucun fournisseur d’IA externe n’est contacté.

Saisir ses propres identifiants ÉcoleDirecte dans le formulaire local, puis répondre soi-même à l’éventuelle vérification. Le connecteur n’est pas agréé Aplim ; il utilise un protocole communautaire et peut nécessiter une adaptation aux réponses d’un établissement. L’archive n’inclut aucune session, aucun identifiant ni document personnel du navigateur.

## Résultats et vie scolaire

- La moyenne générale et les moyennes par matière viennent **uniquement des périodes publiées par ÉcoleDirecte**, affichées avec deux décimales. Aucune moyenne de remplacement n’est calculée. Une moyenne non transmise reste vide.
- Le graphique principal relie les notes individuelles par matière, aux dates réellement reçues. Les barèmes sont ramenés sur 20 pour le tracé uniquement. Un second onglet montre les moyennes officielles ; une seule période y donne un point. Aucun historique de moyenne n’est inventé.
- Toutes les notes reçues sont conservées, y compris les mentions non numériques, notes non significatives et coefficients non renseignés. Une mention « Abs » ne devient jamais zéro.
- L’historique conserve chaque absence et retard transmis, même en dehors des quatre dernières semaines, avec date, plage horaire/libellé lorsqu’ils existent, durée et justification.
- Les compteurs d’assiduité restent limités aux quatre dernières semaines. Une durée en heures reste en heures ; seules les demi-journées explicites sont additionnées comme telles.
- L’espace professeur retrouve le tableau d’origine et son indice de suivi, expliqué dans le simulateur. Il utilise les moyennes publiées et l’assiduité reçue ; une donnée manquante ne vaut jamais zéro. Le professeur décide du suivi.

## Conseils et conversation

L’accueil affiche immédiatement les observations du dossier : moyennes publiées, comparaisons entre périodes, différences entre évaluations, séries de résultats en recul ou en progrès, absences et contrôles. Les comparaisons ne supposent pas des difficultés identiques entre contrôles et n’attribuent pas de cause à une baisse. Le modèle ajoute des actions pour les matières et les révisions ; la vie scolaire reste présentée factuellement. Le statut de suivi du professeur n’est pas affiché à l’élève. « En parler » ouvre la conversation ; les questions et réponses sont séparées par enfant.

Les données ÉcoleDirecte sont actualisées toutes les cinq minutes lorsque l’accueil, les résultats ou les conseils sont visibles et au repos. Il s’agit d’une interrogation périodique, pas d’un flux poussé par ÉcoleDirecte. Une nouvelle note ou un document modifié invalide le bilan ; les observations sont recalculées et les conseils sont renouvelés à l’ouverture de l’accueil ou des conseils.

Une demande de liste de devoirs restitue directement toutes les échéances reçues, sans génération de faits. Les boutons permettent de choisir un contrôle. Une demande de fiche ou d’entraînement retrouve la matière, la date et les documents associés, puis enregistre le résultat dans le classeur. Les documents liés à un autre contrôle sont exclus lorsque le contrôle cible est connu.

Le moteur `server/tutor.mjs` construit le contexte à partir du dossier autorisé, de la conversation et des cours disponibles, puis sollicite un modèle de langage local via `127.0.0.1:11434`. Il ne remplace pas une erreur par une réponse préécrite. Il n’a aucun outil de navigation ou d’écriture dans ÉcoleDirecte. Il ne recalcule pas les moyennes. Une seule génération fonctionne à la fois, avec annulation et délai maximal. Le modèle rapide reste disponible trois minutes ; les modèles de préparation sont libérés après 30 secondes sans utilisation. Une question simple a pris environ 3,3 secondes et un bilan de trois observations environ 8,8 secondes lors des essais sur ce Mac (mesures ponctuelles, non garanties) ; le premier chargement et les préparations longues peuvent prendre une à plusieurs minutes. Les réponses peuvent se tromper : les explications, calculs et transcriptions restent à vérifier.

## Classeur de révisions

1. Ouvrir **Mes cours** pour voir l’emploi du temps de la semaine, naviguer entre les semaines et choisir une matière ou un cours.
2. Cliquer sur une séance pour consulter le contenu publié à cette date et ajouter son propre compte rendu. Une séance à venir est grisée mais consultable ; son compte rendu reste désactivé jusqu’à la fin. Les notes personnelles munies d’un titre sont enregistrées automatiquement après une seconde de pause. Les comptes rendus sont associés à une séance précise.
3. Ajouter jusqu’à six photos JPG, PNG ou WebP par document. Les images sont redimensionnées dans le navigateur. La lecture locale commence automatiquement à l’ajout. La transcription reste modifiable et « Lire cette photo » permet de réessayer. Avec un titre, le document est enregistré après lecture. Les passages illisibles et formules doivent être vérifiés. HEIC et PDF ne sont pas acceptés dans cette version.
4. Dans **Devoirs**, retrouver les échéances reçues, préparer un contrôle particulier et lui associer des documents avec « Ajouter des documents pour ce contrôle », y compris avant la date du contrôle. ÉcoleDirecte ne renseigne pas systématiquement un indicateur « contrôle » : les consignes restent affichées dans tous les cas.
5. Dans **Réviser**, sélectionner les textes à utiliser et préciser un objectif ou une date. Une fiche synthétise les notions et méthodes ; un entraînement propose quatre exercices de cinq points, avec un corrigé distinct relu par un deuxième passage du modèle. Cette relecture ne garantit pas l’absence d’erreur. Le contenu est généré à partir des cours et anciens contrôles sélectionnés, sans prétendre reproduire le futur sujet du professeur.
6. Retrouver, exporter et réutiliser les préparations enregistrées. « Exporter le classeur » télécharge une sauvegarde JSON des documents et préparations ; le réimport n’est pas encore proposé.

Le planning charge les sept jours demandés et les détails des devoirs des trois semaines proches, avec au maximum 21 lectures de journées. La liste de devoirs reçue reste consultable. Un cache de cinq minutes réduit les appels. Les accès d’un compte parent à plusieurs établissements sont sérialisés afin de ne pas mélanger les jetons de contexte.

Les noms des pièces jointes du cahier de textes sont affichés, mais leur contenu n’est **pas téléchargé automatiquement** : les ouvrir dans ÉcoleDirecte et ajouter les photos utiles dans le classeur. Les modules non exposés au compte, les messages privés, documents administratifs, données médicales et adresses ne sont pas importés. « Toutes les informations » signifie ici les données scolaires des modules pris en charge, dans le périmètre autorisé par ÉcoleDirecte, pas un accès supplémentaire aux dossiers.

## Interface verte et accès rétablis

Professeurs : **Tableau de bord**, **Tous les élèves**, **Mon suivi**, **Simulateur**. Le tableau d’origine réunit photo, nom, moyenne publiée, évolution, absences non justifiées en demi-journées et priorité. Recherche, filtres de classe et de priorité, export du bilan et fiches explicatives sont disponibles. Les fiches distinguent les faits des pistes à vérifier et conservent le formulaire de suivi. Les suivis réels restent en mémoire pendant la session, les suivis fictifs dans le navigateur. Ils ne sont jamais envoyés aux élèves.

Élèves et parents : **Accueil**, **Mes résultats**, **Mes devoirs**, **Cours et révisions**, **Mes conseils**. L’accueil conserve la courbe, les indicateurs, les dernières notes et trois observations par matières distinctes. Tous les conseils restent accessibles : une ligne par matière se déplie pour consulter les observations et ouvrir la discussion correspondante. Le classeur conserve l’emploi du temps, les cours, les photos, les documents liés aux contrôles et les préparations.

Le simulateur reprend quatre situations fictives et des réglages de moyenne, d’absences et de retards. Il utilise la même règle d’indice que le tableau : baisse des résultats (40 points), niveau de moyenne (20), absences (30), retards (10). Les seuils sont 30 pour « À observer » et 60 pour « Prioritaire ». Cette règle de démonstration n’est pas une probabilité et n’est pas validée statistiquement. Les données incomplètes n’obtiennent pas de score. Les explications de la fiche peuvent aussi mentionner une difficulté dans une matière, qui n’entre pas dans le calcul de l’indice général.

L’atelier professeur de création de contrôles et l’agenda supplémentaire restent hors navigation. Les documents locaux existants sont conservés. Aucun service d’IA externe n’a été ajouté.

## Conservation et séparation des données

Le serveur écoute uniquement sur `127.0.0.1`. Il contrôle l’hôte, l’origine et le type des requêtes. Le cookie de session est HttpOnly et SameSite=Strict. Les jetons ÉcoleDirecte restent en mémoire côté serveur. Les mots de passe ne sont conservés que le temps de l’authentification et de la vérification. Ils ne sont ni écrits sur disque ni journalisés. Les domaines ÉcoleDirecte et Ollama sont fixés dans le code ; aucune URL fournie par le client ne peut rediriger les appels.

Les notes, l’assiduité, les conversations et les préparations temporaires restent en mémoire. La session expire après 30 minutes sans opération authentifiée, ou après 5 minutes si une vérification n’est pas terminée. Une déconnexion annule les tâches liées au compte et supprime l’accès aux résultats en attente.

**Les documents, leurs transcriptions, les préparations et les contenus de cours/devoirs consultés sont conservés dans IndexedDB, dans ce navigateur sur ce Mac**, séparés par compte et enfant. Ils persistent après rechargement et déconnexion ; ils ne sont pas synchronisés avec ÉcoleDirecte ni avec un autre appareil. Le bouton Supprimer retire un document ; l’export permet d’en garder une copie. Sur un ordinateur partagé, ces fichiers font partie des données locales du navigateur.

Les portraits fictifs sont utilisés uniquement dans la démonstration. Un vrai dossier affiche la photo autorisée par ÉcoleDirecte ou des initiales si elle est absente.

## Vérifications

`node --test tests/*.test.mjs`

106 tests automatiques couvrent notamment l’authentification, les comptes parent/élève/professeur, l’isolation des dossiers, les moyennes officielles, l’assiduité, les cours, les générations et les observations factuelles de l’espace professeur, les priorités, les données manquantes et la séparation entre constats et pistes explicatives. Les contrôles de données des anciens modules restent testés même si ces modules ne sont plus accessibles dans la navigation.

La restauration est vérifiée dans le navigateur sur un serveur de données fictives : tableau professeur, filtre des priorités, fiches explicatives, changement de scénario et de curseur dans le simulateur, liens élèves, devoirs, ajout de documents pour un contrôle, conseils par matière et ouverture de la discussion. Les fichiers servis par l’application locale correspondent à cette version. Aucun compte professeur réel n’a été utilisé.

## Démonstration autonome

`Repere.html` permet de découvrir les élèves et données fictifs sans serveur. La connexion ÉcoleDirecte et la génération nécessitent le serveur local et sont indisponibles depuis le fichier seul. Reconstruction : `python3 build_standalone.py Repere.html`.

## Sources techniques

- [Moyenne ÉcoleDirecte](https://github.com/feyli/ecoledirecte-moyenne), pour les appels de notes avec authentification.
- [EcoleDirecteMCP](https://github.com/jeromeboivin/EcoleDirecteMCP), pour GTK, X-Token, double authentification, contextes famille, emploi du temps et cahier de textes.
- [Documentation communautaire ÉcoleDirecte](https://github.com/EduWireApps/ecoledirecte-api-docs), pour les formats de données.
- [API locale Ollama](https://docs.ollama.com/api/chat), pour les messages, images et sorties structurées du modèle installé.

Les projets ÉcoleDirecte sont des références communautaires, pas une garantie contractuelle de compatibilité ni une clé API universelle.

## Organisation du code

- `server.mjs` : serveur local, sessions, routes et tâches de génération.
- `server/connector.mjs` : authentification et lectures ÉcoleDirecte autorisées.
- `server/normalize.mjs`, `attendance.mjs`, `planner.mjs`, `identity.mjs` : données, périodes, événements, cours et profils.
- `server/tutor.mjs` : contexte, lecture des images et génération locale.
- `dist/app.js`, `styles.css` : interface.
- `dist/insights.mjs` : observations vérifiables, séries de notes et sélection des contrôles/documents.
- `dist/study.mjs` : semaine, classeur, IndexedDB et documents.
- `dist/teaching.mjs`, `agenda.mjs`, `workspace.mjs` : atelier professeur, agenda, stockage séparé et synthèse des classes.
- `dist/tutor-client.mjs` : progression et annulation des préparations.
- `dist/engine.mjs`, `progress.mjs` : moyennes publiées, courbe et indices. Les anciennes fonctions de conseils à règles de `coach.mjs` sont conservées pour leurs tests historiques mais ne répondent plus aux utilisateurs.
- `tests/` : tests et données fictives ; jamais injectés dans l’application normale.
