import test from 'node:test';
import assert from 'node:assert/strict';
import {weightedAverage,evaluate,createDemoStudents,metricsFor} from '../dist/engine.mjs';
const regular={previous:13,current:13.4,currentCount:8,previousCount:8,absenceHalfDays:0,lates:0};
test('Normalise les barèmes et applique les coefficients sans transformer une absence en zéro',()=>{
 assert.equal(weightedAverage([{value:8,outOf:10,weight:2},{value:10,outOf:20,weight:1},{value:null,outOf:20,weight:1}]),14);
 assert.equal(weightedAverage([{value:0,outOf:20,weight:1}]),0);
 assert.equal(weightedAverage([{value:null,outOf:20,weight:1},{value:25,outOf:20,weight:1},{value:4,outOf:0,weight:1}]),null);
});
test('Le scénario de baisse marquée donne 72 et une priorité haute',()=>{
 const a=evaluate({...regular,previous:14.4,current:9.2,absenceHalfDays:3,lates:3});assert.equal(a.score,72);assert.equal(a.level,'high');assert.equal(a.parts.length,4);
});
test('Le manque de notes ou d’assiduité ne donne jamais un résultat rassurant',()=>{
 for(const missing of [{currentCount:2},{previousCount:2},{absenceHalfDays:null},{lates:null},{current:NaN},{previous:21}]){const a=evaluate({...regular,...missing});assert.equal(a.score,null);assert.equal(a.level,'missing');}
});
test('La reprise des résultats sans absence ne déclenche pas d’alerte',()=>{
 const a=evaluate({...regular,previous:9,current:12});assert.equal(a.score,0);assert.equal(a.level,'stable');
});
test('La somme arrondie utilise correctement les frontières des niveaux',()=>{
 assert.equal(evaluate({...regular,previous:13,current:10,absenceHalfDays:4}).score,60);
 assert.equal(evaluate({...regular,previous:13,current:10,absenceHalfDays:4}).level,'high');
 assert.equal(evaluate({...regular,previous:13,current:13.4,absenceHalfDays:4}).level,'watch');
});
test('Un total à un demi-point est arrondi vers le haut',()=>{
 assert.equal(evaluate({...regular,previous:13.1,current:10.7,absenceHalfDays:3,lates:2}).score,51);
});
test('Les absences justifiées, le nom et le portrait ne modifient pas le calcul',()=>{
 assert.deepEqual(evaluate(regular),evaluate({...regular,justifiedHalfDays:80,firstName:'Autre prénom',portrait:11}));
});
test('Les scénarios extrêmes restent bornés entre 0 et 100',()=>{
 for(let previous=0;previous<=20;previous+=2)for(let current=0;current<=20;current+=2)for(const absenceHalfDays of [0,4,50]){const a=evaluate({...regular,previous,current,absenceHalfDays,lates:15});assert.ok(a.score>=0&&a.score<=100);assert.ok(a.parts.every(p=>p.points>=0&&p.points<=p.max));}
 assert.equal(evaluate({...regular,previous:20,current:0,absenceHalfDays:20,lates:10}).score,100);
});
test('Une augmentation des absences ne réduit jamais la priorité',()=>{
 let last=-1;for(let absenceHalfDays=0;absenceHalfDays<=20;absenceHalfDays++){const current=evaluate({...regular,absenceHalfDays}).score;assert.ok(current>=last);last=current;}
});
test('Les 12 élèves ont des notes cohérentes et le jeu couvre les trois niveaux',()=>{
 const students=createDemoStudents();assert.equal(students.length,12);assert.equal(new Set(students.map(s=>s.id)).size,12);
 const analyses=students.map(s=>evaluate(metricsFor(s)));assert.equal(analyses.filter(a=>a.level==='high').length,3);assert.equal(analyses.filter(a=>a.level==='watch').length,3);assert.equal(analyses.filter(a=>a.level==='stable').length,6);
 assert.ok(students.every(s=>s.grades.length===16));
 const hugo=students.find(s=>s.firstName==='Hugo');assert.equal(evaluate(metricsFor(hugo)).score,41);
});

test('Les absences répétées seules déclenchent un signal même avec de bonnes notes',()=>{
 assert.equal(evaluate({...regular,absenceHalfDays:4}).level,'watch');
 assert.equal(evaluate({...regular,previous:9,current:12,absenceHalfDays:20}).level,'watch');
});
