import test from 'node:test';
import assert from 'node:assert/strict';
import {createDemoStudents} from '../dist/engine.mjs';
import {analyzeStudent,composeAdvice,subjectResults,sessionSummary} from '../dist/coach.mjs';
const students=createDemoStudents();
test('Les conseils se basent sur les valeurs du dossier et désignent une matière précise',()=>{
 const emma=students[0],a=analyzeStudent(emma),r=composeAdvice(emma);
 assert.ok(a.signals.some(s=>s.id==='decline'));assert.ok(a.signals.some(s=>s.id==='attendance'));assert.ok(a.signals.some(s=>s.id==='subject'));assert.ok(r.evidence.some(t=>t.includes('14,4')&&t.includes('9,2')));
 const maths=composeAdvice(emma,{question:'Comment progresser en maths ?'});assert.equal(maths.topic,'subject');assert.match(maths.title,/Mathématiques/);assert.ok(maths.steps.some(t=>t.includes('Mathématiques')));
});
test('Une autre piste varie le texte sans modifier les faits ni les priorités',()=>{
 for(const student of students){const first=composeAdvice(student);for(let variant=1;variant<=2;variant++){const next=composeAdvice(student,{variant});assert.deepEqual(first.evidence,next.evidence);assert.deepEqual(first.signalIds,next.signalIds);assert.notEqual(first.steps.join(' '),next.steps.join(' '));}}
});
test('Le bilan incomplet ne donne pas de message global rassurant',()=>{
 const missing=structuredClone(students[4]);missing.attendance.absenceHalfDays=null;
 for(let variant=0;variant<3;variant++){const r=composeAdvice(missing,{variant});assert.equal(r.signalIds[0],'missing');assert.match(r.lead,/partiel|manquent|compléter/);assert.ok(!r.lead.includes('Pas de signal marqué'));}
});
test('De bonnes notes ne masquent pas les absences répétées',()=>{
 const good=structuredClone(students[4]);good.attendance.absenceHalfDays=4;const r=composeAdvice(good);assert.equal(r.signalIds[0],'attendance');assert.ok(r.steps[0].includes('vie scolaire'));
});
test('Les absences justifiées et l’identité ne dégradent pas les conseils',()=>{
 const s=students[4],changed=structuredClone(s);changed.firstName='Autre';changed.portrait=9;changed.attendance.justifiedHalfDays=20;
 assert.deepEqual(composeAdvice(s),composeAdvice(changed));
});
test('Un historique trop court ne crée pas une fausse tendance par matière',()=>{
 const s=structuredClone(students[0]);s.grades=s.grades.filter((g,i)=>i===0||i===8);const subject=subjectResults(s)[0];assert.equal(subject.comparable,false);const r=composeAdvice(s,{question:'Mathématiques'});assert.match(r.lead,/trop peu/);assert.ok(!r.evidence.some(t=>t.startsWith('Évolution')));
});
test('Les demandes hors périmètre sont reconnues comme non prises en charge',()=>{
 const r=composeAdvice(students[0],{question:'Quelle est la météo à Paris ?'});assert.equal(r.topic,'unknown');assert.equal(r.evidence.length,0);
});
test('Les séances ne sont comptées que pour le dossier concerné',()=>{
 const sessions=[{studentId:students[0].id},{studentId:students[1].id}];const r=composeAdvice(students[0],{question:'Organiser mes révisions',sessions});assert.match(r.evidence[0],/^1 séance/);
 const summary=sessionSummary({minutes:20,subject:'Maths',note:'Deux exercices',next:'Revoir une erreur'});assert.match(summary,/20 min/);assert.match(summary,/Deux exercices/);assert.match(summary,/Revoir une erreur/);
});
