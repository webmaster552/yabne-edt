import test from 'node:test';
import assert from 'node:assert/strict';
import {requestJson,followImport} from '../dist/connection.mjs';

test('Une requête bloquée se termine avec un message exploitable',async()=>{
 const fetchImpl=(_,{signal})=>new Promise((_,reject)=>signal.addEventListener('abort',()=>reject(new Error('aborted'))));
 await assert.rejects(requestJson('/api/challenge',{choice:0},{fetchImpl,timeoutMs:5}),{code:'REQUEST_TIMEOUT'});
});
test('Suivi de chargement : plusieurs étapes puis dossier réel, sans relancer l’import',async()=>{
 const payload={account:{role:'student'},students:[{id:'ed-42'}]},states=[{status:'running',progress:{phase:'grades'}},{status:'running',progress:{phase:'attendance'}},{status:'complete',payload}],phases=[],paths=[];
 const result=await followImport({request:async path=>{paths.push(path);return states.shift();},onUpdate:s=>phases.push(s.progress?.phase),pollMs:0});
 assert.equal(result,payload);assert.deepEqual(paths,['/api/sync','/api/sync','/api/sync']);assert.deepEqual(phases.slice(0,2),['grades','attendance']);
});
test('Une erreur d’import est affichable et conserve son code de session expirée',async()=>{
 await assert.rejects(followImport({initial:{status:'error',failure:{status:401,code:'ED_521',message:'Reconnectez-vous.'}}}),{status:401,code:'ED_521'});
 await assert.rejects(followImport({initial:{status:'complete',payload:{students:[]}}}),/incomplètes/);
});
test('Une réponse tardive est ignorée après la déconnexion',async()=>{
 let active=true,updates=0;
 const result=await followImport({request:async()=>{active=false;return {status:'complete',payload:{account:{},students:[]}};},isActive:()=>active,onUpdate:()=>updates++});
 assert.equal(result,null);assert.equal(updates,0);
});
