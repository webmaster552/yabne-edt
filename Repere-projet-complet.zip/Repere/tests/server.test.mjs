import test from 'node:test';
import assert from 'node:assert/strict';
import {once} from 'node:events';
import http from 'node:http';
import {createAppServer} from '../server.mjs';
import {EcoleDirecteConnector} from '../server/connector.mjs';
import {makeFixtureFetch,makeFamilyFetch,testNow} from './fixtures.mjs';
async function start(t,config={}){
 const server=createAppServer({connectorFactory:()=>new EcoleDirecteConnector({...makeFixtureFetch(),now:testNow}),...config});server.listen(0,'127.0.0.1');await once(server,'listening');t.after(()=>new Promise(r=>{server.closeAllConnections();server.close(r);}));
 const base=`http://127.0.0.1:${server.address().port}`;let cookie='';
 const call=async(path,data,override={})=>{const result=await fetch(base+path,{method:data===undefined?'GET':'POST',headers:{...(data===undefined?{}:{'Content-Type':'application/json',Origin:base,'X-Repere-Request':'1'}),...(cookie?{Cookie:cookie}:{}),...override},body:data===undefined?undefined:JSON.stringify(data)});if(result.headers.get('set-cookie'))cookie=result.headers.get('set-cookie').split(';')[0];return result;};
 return {call,base};
}
test('Connexion locale, cookie HttpOnly, import et déconnexion',async t=>{
 const {call}=await start(t);assert.equal((await call('/api/session')).status,200);assert.equal((await call('/api/sync',{})).status,401);
 const login=await call('/api/login',{username:'test-local',password:'test-fictif'});assert.equal(login.status,200);assert.match(login.headers.get('set-cookie'),/HttpOnly; SameSite=Strict/);
 const data=await (await call('/api/sync',{})).json();assert.equal(data.students.length,1);assert.equal(data.students[0].attendance.absenceHalfDays,2);assert.ok(!JSON.stringify(data).includes('fixture-secret'));
 assert.equal((await call('/api/eleves/999')).status,404);await call('/api/logout',{});assert.equal((await call('/api/sync',{})).status,401);
});
test('Rejet des origines étrangères, des hôtes étrangers et des fichiers serveur',async t=>{
 const {call,base}=await start(t);assert.equal((await call('/api/login',{username:'x',password:'y'},{Origin:'https://foreign.example'})).status,403);assert.equal((await call('/api/session',undefined,{'Sec-Fetch-Site':'cross-site'})).status,403);const foreignHostStatus=await new Promise((resolve,reject)=>{http.get(base+'/api/session',{headers:{Host:'foreign.example'}},r=>{r.resume();resolve(r.statusCode);}).on('error',reject);});assert.equal(foreignHostStatus,403);
 assert.equal((await call('/server.mjs')).status,404);assert.equal((await call('/.openai/hosting.json')).status,404);assert.equal((await call('/api/login',{username:'x',password:'z'.repeat(13000)})).status,413);
});
test('Expiration de session retire les données et accès API',async t=>{
 let time=Date.now();const {call}=await start(t,{now:()=>time});await call('/api/login',{username:'x',password:'y'});time+=1800001;assert.equal((await call('/api/sync',{})).status,401);assert.equal((await (await call('/api/session')).json()).status,'disconnected');
});
test('Déconnexion pendant import empêche le retour de données',async t=>{
 let resolveSync,started;const entered=new Promise(r=>{started=r;});const fixture={account:null,pending:null,clear(){this.account=null;},publicAccount(){return this.account;},async login(){this.account={role:'student',name:'Fictif'};return {status:'authenticated',account:this.account};},async sync(){started();return new Promise(r=>{resolveSync=r;});}};
 const {call}=await start(t,{connectorFactory:()=>fixture});await call('/api/login',{username:'x',password:'y'});const pending=call('/api/sync',{});await entered;await call('/api/logout',{});resolveSync({students:[{secret:'should-not-return'}]});const response=await pending;assert.equal(response.status,401);assert.ok(!(await response.text()).includes('should-not-return'));
});
test('Limitation des tentatives sans réessais automatiques',async t=>{
 const {call}=await start(t,{connectorFactory:()=>new EcoleDirecteConnector({...makeFixtureFetch({denied:true}),now:testNow})});for(let i=0;i<5;i++)assert.equal((await call('/api/login',{username:'x',password:'y'})).status,401);assert.equal((await call('/api/login',{username:'x',password:'y'})).status,429);
});

test('La question de sécurité peut être reprise après rechargement sans exposer les secrets',async t=>{
 const {call}=await start(t,{connectorFactory:()=>new EcoleDirecteConnector({...makeFixtureFetch({challenge:'question'}),now:testNow})});
 const question=await (await call('/api/login',{username:'x',password:'secret-fictif'})).json();
 const session=await (await call('/api/session')).json();assert.equal(session.status,'challenge');assert.deepEqual(session.challenge,question);assert.ok(!JSON.stringify(session).includes('secret-fictif'));assert.ok(!JSON.stringify(session).includes('fixture-pending'));
 await call('/api/challenge',{choice:0});const ready=await (await call('/api/session')).json();assert.equal(ready.status,'authenticated');assert.equal(ready.challenge,null);
});
test('Import en arrière-plan : progression, reprise sans doublon et résultat conservé',async t=>{
 let finish,calls=0;const connector=new EcoleDirecteConnector({...makeFixtureFetch(),now:testNow});const original=connector.sync.bind(connector);
 connector.sync=async notify=>{calls++;notify({phase:'grades',completed:0,total:1});await new Promise(r=>finish=r);return original(notify);};
 const {call}=await start(t,{connectorFactory:()=>connector});await call('/api/login',{username:'x',password:'y'});
 assert.equal((await call('/api/sync',{background:true})).status,202);
 const status=await (await call('/api/sync')).json();assert.equal(status.status,'running');assert.equal(status.progress.phase,'grades');assert.equal((await (await call('/api/session')).json()).syncStatus,'running');
 await call('/api/sync',{background:true});assert.equal(calls,1);finish();
 let done;for(let i=0;i<20;i++){done=await (await call('/api/sync')).json();if(done.status==='complete')break;await new Promise(r=>setTimeout(r,1));}
 assert.equal(done.status,'complete');assert.equal(done.payload.students.length,1);assert.equal((await (await call('/api/sync')).json()).payload.account.establishment,'Établissement de test');assert.ok(!JSON.stringify(done).includes('fixture-secret'));
});
test('Un import en arrière-plan annulé ne restaure pas une session déconnectée',async t=>{
 let finish;const connector=new EcoleDirecteConnector({...makeFixtureFetch(),now:testNow});connector.sync=async()=>new Promise(r=>finish=r);
 const {call}=await start(t,{connectorFactory:()=>connector});await call('/api/login',{username:'x',password:'y'});await call('/api/sync',{background:true});await call('/api/logout',{});finish({students:[{id:'private-student'}]});
 assert.equal((await call('/api/sync')).status,401);assert.equal((await (await call('/api/session')).json()).status,'disconnected');
});


test('La session parent ne renvoie que ses enfants et protège les photos par identifiant de famille',async t=>{
 const {call}=await start(t,{connectorFactory:()=>new EcoleDirecteConnector({...makeFamilyFetch(),now:testNow})});
 const login=await (await call('/api/login',{username:'parent',password:'fictif'})).json();assert.equal(login.account.role,'parent');
 const data=await (await call('/api/sync',{})).json();assert.equal(data.students.length,2);assert.ok(data.students.every(s=>s.id.startsWith('ed-70-')));
 const photo=await call('/api/photo/ed-70-42');assert.equal(photo.status,200);assert.equal(photo.headers.get('content-type'),'image/png');
 assert.equal((await call('/api/photo/ed-999-42')).status,404);assert.equal((await call('/api/photo/ed-42')).status,404);
});

test('Le moteur refuse un autre enfant et les tâches disparaissent à la déconnexion',async t=>{
 let resolveAnswer,called=0;
 const tutor={status:async()=>({available:true,model:'test'}),generate:async(input,{student})=>{called++;assert.equal(student.id,'ed-42');return new Promise(r=>resolveAnswer=r);}};
 const {call}=await start(t,{tutor});assert.equal((await call('/api/tutor',{kind:'advice',studentId:'ed-42'})).status,401);
 await call('/api/login',{username:'x',password:'y'});await call('/api/sync',{});
 assert.equal((await call('/api/tutor',{kind:'advice',studentId:'ed-43'})).status,403);assert.equal(called,0);
 const job=await (await call('/api/tutor',{kind:'advice',studentId:'ed-42'})).json();assert.equal(job.status,'running');
 assert.equal((await call('/api/tutor',{kind:'advice',studentId:'ed-42'})).status,409);
 await call('/api/logout',{});resolveAnswer({title:'Privé',body:'Ne doit plus être consultable'});await new Promise(r=>setImmediate(r));assert.equal((await call('/api/tutor/jobs/'+job.id)).status,404);
});
test('Les préparations sont suivies, annulables et ne sont pas partagées entre sessions',async t=>{
 const tutor={status:async()=>({available:true}),generate:async()=>({title:'Fiche',body:'Contenu généré'})};const {call,base}=await start(t,{tutor});
 await call('/api/login',{username:'x',password:'y'});await call('/api/sync',{});const job=await (await call('/api/tutor',{kind:'advice',studentId:'ed-42'})).json();await new Promise(r=>setImmediate(r));
 const result=await (await call('/api/tutor/jobs/'+job.id)).json();assert.equal(result.status,'complete');assert.equal(result.answer.body,'Contenu généré');
 assert.equal((await fetch(base+'/api/tutor/jobs/'+job.id)).status,404);await call('/api/tutor/jobs/'+job.id,{});assert.equal((await call('/api/tutor/jobs/'+job.id)).status,404);
});
test('Le planning valide le dossier et sérialise les accès ÉcoleDirecte',async t=>{
 const {call}=await start(t);await call('/api/login',{username:'x',password:'y'});await call('/api/sync',{});
 assert.equal((await call('/api/planner',{studentId:'ed-999',start:'2026-10-19'})).status,403);
 const p=await (await call('/api/planner',{studentId:'ed-42',start:'2026-10-19'})).json();assert.equal(p.timetable.length,5);assert.equal(p.homework[0].test,true);
});

test('Seul un professeur authentifié prépare sans dossier élève ; les sessions restent isolées',async t=>{
 const calls=[];const tutor={status:async()=>({available:true}),generate:async(input,context)=>{calls.push({input,context});return {title:'Séance',body:'Document fictif'};}};
 const student=await start(t,{tutor});await student.call('/api/login',{username:'x',password:'y'});
 const input={scope:'teacher',kind:'lesson',teaching:{level:'4e',className:'4e B',duration:30,difficulty:'standard'},materials:[{text:'Cours'}]};
 assert.equal((await student.call('/api/tutor',input)).status,403);assert.equal(calls.length,0);
 const teacher=await start(t,{tutor,connectorFactory:()=>new EcoleDirecteConnector({...makeFixtureFetch({teacher:true}),now:testNow})});
 assert.equal((await teacher.call('/api/tutor',input)).status,401);await teacher.call('/api/login',{username:'prof',password:'fictif'});
 const result=await teacher.call('/api/tutor',input);assert.equal(result.status,202);const {id}=await result.json();
 let answer;for(let i=0;i<10;i++){answer=await (await teacher.call('/api/tutor/jobs/'+id)).json();if(answer.status==='complete')break;}
 assert.equal(answer.status,'complete');assert.equal(calls[0].context.student,undefined);assert.equal(calls[0].context.planner,undefined);
 assert.equal((await student.call('/api/tutor/jobs/'+id)).status,404);await teacher.call('/api/logout',{});assert.equal((await teacher.call('/api/tutor/jobs/'+id)).status,404);
});
