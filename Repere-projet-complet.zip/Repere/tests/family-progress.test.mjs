import test from 'node:test';
import assert from 'node:assert/strict';
import {EcoleDirecteConnector} from '../server/connector.mjs';
import {normalizedStudent,normalizeAttendance,halfDays,windows} from '../server/normalize.mjs';
import {gradeHistory,overviewAverage,automaticAdvice,answerFollowup} from '../dist/progress.mjs';
import {createDemoStudents} from '../dist/engine.mjs';
import {makeFamilyFetch,testNow,notes,life} from './fixtures.mjs';

test('Compte parent : seuls les enfants rattachés sont importés, avec des dossiers distincts',async()=>{
 const fixture=makeFamilyFetch(),connector=new EcoleDirecteConnector({...fixture,now:testNow});const login=await connector.login('parent','fictif');
 assert.equal(login.account.role,'parent');assert.deepEqual(login.account.children.map(c=>c.id),['ed-70-42','ed-70-43']);
 const data=await connector.sync();assert.equal(data.students.length,2);assert.equal(data.students[0].firstName,'Nina');assert.equal(data.students[1].firstName,'Mathis');assert.equal(data.students[1].establishment,'Lycée Victor Hugo');assert.notEqual(data.students[0].photoUrl,data.students[1].photoUrl);assert.equal(data.students[1].attendance.absenceHalfDays,0);
 assert.ok(!JSON.stringify(data).includes('family-secret'));assert.ok(!JSON.stringify(data).includes('idLogin'));assert.ok(fixture.requests.every(r=>!r.path.includes('/eleves/70/')));
 await assert.rejects(connector.photo('ed-70-999'),{code:'NO_PHOTO'});connector.clear();assert.equal(connector.children.size,0);
});
test('Deux établissements parent : le contexte est changé avant chaque dossier',async()=>{
 const fixture=makeFamilyFetch({twoAccounts:true}),connector=new EcoleDirecteConnector({...fixture,now:testNow});await connector.login('parent','fictif');
 const data=await connector.sync();assert.deepEqual(data.students.map(s=>s.id),['ed-70-42','ed-71-43']);assert.equal(fixture.requests.filter(r=>r.path.includes('renewtoken')).length,1);
 await connector.sync();assert.equal(fixture.requests.filter(r=>r.path.includes('renewtoken')).length,3);
});
test('Un contexte famille incorrect bloque la lecture de l’autre enfant',async()=>{
 const fixture=makeFamilyFetch({twoAccounts:true,wrongContext:true}),connector=new EcoleDirecteConnector({...fixture,now:testNow});await connector.login('parent','fictif');await assert.rejects(connector.sync(),{code:'FAMILY_CONTEXT'});assert.ok(!fixture.requests.some(r=>r.path.includes('/43/')));
});
test('Une absence en heures conserve les retards, les justifications connues et son détail',()=>{
 const data={absencesRetards:[{...life.absencesRetards[0],libelle:'2 heures'},...life.absencesRetards.slice(1)]};
 const s=normalizedStudent({id:42},notes,data,windows(testNow()));assert.equal(s.attendance.absenceHalfDays,null);assert.equal(s.attendance.absenceEvents,1);assert.equal(s.attendance.justifiedHalfDays,1);assert.equal(s.attendance.lates,1);assert.equal(s.attendance.events[0].durationLabel,'2 heures');assert.ok(!('motif' in s.attendance.events[0]));
});
test('Dates françaises et demi-journée(s) explicites sont reconnues sans convertir les heures',()=>{
 assert.equal(halfDays({libelle:'2 demi‑journée(s)'}),2);assert.equal(halfDays({libelle:'une demi-journée'}),1);assert.equal(halfDays({libelle:'8 heures'}),null);
 const data=normalizeAttendance({absencesRetards:[{typeElement:'Absence',displayDate:'du lundi 5 octobre 2026 au mardi 6 octobre 2026',libelle:'4 demi-journées',justifie:'oui'}]},windows(testNow()));
 assert.equal(data.justifiedHalfDays,4);assert.equal(data.lates,0);
});
test('La courbe reprend les moyennes publiées, jamais une moyenne calculée des notes',()=>{
 const s={grades:[{date:'2026-10-02',subject:'Maths',value:5,outOf:10,weight:2}],reportPeriods:[{label:'T1',end:'2026-12-20',average:13.78,subjects:[{subject:'Maths',average:12.64}]}]};
 assert.equal(gradeHistory(s)[0].average,13.78);assert.equal(gradeHistory(s,{subject:'Maths'})[0].average,12.64);assert.deepEqual(gradeHistory({grades:s.grades}),[]);
});
test('Moyenne affichée : bulletin correspondant aux notes, sinon aucune moyenne calculée',()=>{
 const s=createDemoStudents()[0];s.reportPeriods=[{start:'2026-09-01',end:'2026-12-01',average:13.3,label:'1er trimestre'}];assert.equal(overviewAverage(s).value,13.3);assert.equal(overviewAverage({grades:[]}).value,null);
});
test('Les conseils sont automatiques même si l’assiduité manque, sans prétendre à un bilan complet',()=>{
 const s=createDemoStudents()[0];s.attendance.absenceHalfDays=null;const cards=automaticAdvice(s);assert.ok(cards.length>0);assert.ok(cards.every(c=>c.action&&c.evidence));assert.ok(!cards.some(c=>c.id==='missing'));assert.ok(cards.some(c=>c.id==='decline'));assert.equal(automaticAdvice({grades:[],attendance:{}})[0].id,'waiting');
});
test('Les questions de suivi conservent la matière et les sujets hors périmètre restent reconnus',()=>{
 const s=createDemoStudents()[0];const answer=answerFollowup(s,'Un exemple ?',{context:'Mathématiques'});assert.equal(answer.topic,'subject');assert.match(answer.title,/Mathématiques/);assert.equal(answerFollowup(s,'Quelle est la météo à Paris ?',{context:'Mathématiques'}).topic,'unknown');assert.equal(answerFollowup(s,'Comment je peux m’améliorer ?').topic,'plan');
});
