import test from 'node:test';
import assert from 'node:assert/strict';
import {normalizedStudent,normalizePeriods,windows} from '../server/normalize.mjs';
import {gradeHistory,overviewAverage} from '../dist/progress.mjs';
import {metricsFor,officialSubject} from '../dist/engine.mjs';
import {EcoleDirecteConnector} from '../server/connector.mjs';
import {LocalTutor,tutorContext,validateTutorInput} from '../server/tutor.mjs';
import {normalizeTimetable,normalizeHomework,normalizeDay,schoolText,weekDates} from '../server/planner.mjs';
import {makeFamilyFetch,makeFixtureFetch,testNow,notes,life,plannerFixture} from './fixtures.mjs';
const report=(value='13,75')=>({idPeriode:'T1',periode:'1er trimestre',dateDebut:'2026-09-01',dateFin:'2026-12-20',ensembleMatieres:{moyenneGenerale:value,disciplines:[{discipline:'Mathématiques',moyenne:'12,28',coef:'5'}]}});
const student=()=>normalizedStudent({id:42,classe:{libelle:'4e B'}},{...notes,periodes:[report()]},life,windows(testNow()));
test('Les moyennes générales et par matière restent exactement celles d’ÉcoleDirecte',()=>{
 const s=student();assert.equal(overviewAverage(s).value,13.75);assert.equal(officialSubject(s,'Mathématiques'),12.28);assert.equal(metricsFor(s).current,13.75);assert.equal(metricsFor(s).previous,null);
 assert.equal(gradeHistory(s)[0].average,13.75);assert.equal(gradeHistory(s,{subject:'Mathématiques'})[0].average,12.28);
 s.reportPeriods=normalizePeriods({periodes:[report('')]});assert.equal(overviewAverage(s).value,null);assert.equal(metricsFor(s).current,null);assert.deepEqual(gradeHistory(s),[]);assert.equal(officialSubject(s,'Mathématiques'),12.28);
 s.reportPeriods=[];assert.equal(overviewAverage(s).value,null);assert.equal(metricsFor(s).current,null);assert.deepEqual(gradeHistory(s),[]);
});
test('Tous les retards restent consultables, même hors fenêtre de synthèse et sans date',()=>{
 const events=[...life.absencesRetards,{id:90,typeElement:'Retard',date:'2026-08-02',libelle:'12 minutes',displayDate:'le 2 août 2026 à 09:12'},{id:91,typeElement:'Retard',libelle:'5 minutes'}];
 const s=normalizedStudent({id:42},notes,{absencesRetards:events},windows(testNow()));assert.equal(s.attendance.events.length,5);assert.equal(s.attendance.events[3].durationLabel,'12 minutes');assert.equal(s.attendance.events[4].date,null);assert.equal(s.attendance.lates,null);
});
test('Emploi du temps, cours et contrôles conservent dates et contenus sans exécuter de HTML',()=>{
 const p=plannerFixture('2026-10-19');assert.equal(normalizeTimetable(p.timetable)[0].start,'2026-10-19 08:00:00');assert.equal(normalizeHomework(p.homework)[0].test,true);
 const day=normalizeDay(p.detail,'2026-10-19');assert.match(day[0].lesson,/3x/);assert.match(day[0].homework.text,/équations/);assert.ok(!day[0].lesson.includes('<'));
 assert.equal(schoolText(Buffer.from('<script>alert(1)</script><p>A &amp; B</p>').toString('base64')),'A & B');assert.throws(()=>weekDates('2026-02-30'));assert.equal(weekDates('2026-10-19')[6],'2026-10-25');
});
test('Le planning parent respecte le contexte de chaque enfant et refuse les identifiants étrangers',async()=>{
 const f=makeFamilyFetch({twoAccounts:true}),c=new EcoleDirecteConnector({...f,now:testNow});await c.login('parent','fictif');await c.sync();const a=await c.planner('ed-70-42','2026-10-19');assert.equal(a.availability.timetable,true);assert.equal(a.availability.details,true);assert.match(a.homework[0].text,/équations/);assert.equal(a.timetable.length,5);
 const b=await c.planner('ed-71-43','2026-10-19');assert.equal(b.studentId,'ed-71-43');const count=f.requests.length;await assert.rejects(c.planner('ed-70-999','2026-10-19'),{status:403});assert.equal(f.requests.length,count);await c.planner('ed-71-43','2026-10-19');assert.equal(f.requests.length,count);
 c.clear();await assert.rejects(c.planner('ed-71-43','2026-10-19'),{status:403});
});
test('Un planning absent reste indisponible, sans cours de démonstration',async()=>{
 const f=makeFixtureFetch(),c=new EcoleDirecteConnector({fetchImpl:(url,opts)=>String(url).includes('emploidutemps')?Promise.resolve(new Response(JSON.stringify({code:403}))):f.fetchImpl(url,opts),now:testNow});await c.login('x','y');await c.sync();const p=await c.planner('ed-42','2026-10-19');assert.equal(p.availability.timetable,false);assert.deepEqual(p.timetable,[]);assert.ok(p.warnings.length);
});
test('Le moteur ne peut contacter que le modèle installé en local, avec contexte limité au dossier fourni',async()=>{
 const calls=[];const tutor=new LocalTutor({fetchImpl:async(url,options)=>{calls.push({url,body:JSON.parse(options.body)});return new Response(JSON.stringify({message:{content:JSON.stringify({title:'Méthode',body:'Soustrais 5 aux deux membres.'})},done_reason:'stop'}));}});
 const s=student();const result=await tutor.generate({kind:'chat',question:'Comment commencer ?',history:[{role:'system',content:'fake'},{role:'user',content:'Équations'}]},{student:s});assert.equal(result.body,'Soustrais 5 aux deux membres.');assert.equal(calls[0].url,'http://127.0.0.1:11434/api/chat');assert.equal(calls[0].body.think,false);assert.ok(!calls[0].body.messages.some(m=>m.content==='fake'));assert.ok(JSON.stringify(calls).includes('13.75'));assert.ok(!JSON.stringify(calls).includes('motdepasse'));assert.equal(tutorContext(s).moyennePubliee.moyenne,13.75);
});
test('L’entraînement impose quatre exercices à cinq points et sépare le corrigé',async()=>{
 const tutor=new LocalTutor({fetchImpl:async(url,options)=>new Response(JSON.stringify({done_reason:'stop',message:{content:JSON.stringify(JSON.parse(options.body).format.properties.solutions?{solutions:Array(4).fill('x = 4')}:{title:'Équations',exercises:Array.from({length:4},(_,i)=>({title:'Question '+i,question:'2x = 8',solution:'x = 4'}))})}}))});
 const a=await tutor.generate({kind:'practice',materials:[{title:'Cours',text:'Équations'}]},{student:student()});assert.match(a.body,/Barème : 20 points/);assert.equal(a.body.match(/5 points/g).length,4);assert.ok(!a.body.includes('x = 4'));assert.match(a.correction,/x = 4/);
});
test('Le moteur refuse les photos falsifiées, dossiers trop longs et cours vides',()=>{
 assert.throws(()=>validateTutorInput({kind:'ocr',images:['data:image/png;base64,aGVsbG8=']}),{code:'INVALID_IMAGE'});
 assert.throws(()=>validateTutorInput({kind:'sheet',materials:[]}),{code:'COURSE_REQUIRED'});
 assert.throws(()=>validateTutorInput({kind:'sheet',materials:[{text:'a'.repeat(33000)}]}),{code:'MATERIAL_LIMIT'});
});
test('Une fiche doit contenir une méthode, un exemple et quatre questions, pas seulement recopier le cours',async()=>{
 const input={kind:'sheet',materials:[{title:'Équations',text:'3x + 5 = 17'}]},context={student:student()};
 let answer={title:'Équations',body:'3x + 5 = 17'};
 const tutor=new LocalTutor({fetchImpl:async()=>new Response(JSON.stringify({done_reason:'stop',message:{content:JSON.stringify(answer)}}))});
 await assert.rejects(tutor.generate(input,context),{code:'TUTOR_INCOMPLETE'});
 answer={title:'Équations',essentials:'La même opération sur les deux membres.',method:'Soustraire 5 puis diviser par 3.',example:'3x = 12, donc x = 4.',mistakes:'Ne pas oublier le second membre.',questions:['Que signifie égalité ?','Pourquoi soustraire 5 ?','Résoudre 2x = 8.','Vérifier x = 4.']};
 const result=await tutor.generate(input,context);assert.match(result.body,/La méthode/);assert.match(result.body,/Un exemple résolu/);assert.match(result.body,/4\. Vérifier x = 4/);
});
test('Les erreurs et réponses tronquées du modèle ne deviennent jamais de faux conseils préécrits',async()=>{
 for(const result of [{message:{content:'not json'}},{done_reason:'length',message:{content:'{"title":"X","body":"Y"}'}}]){
  const t=new LocalTutor({fetchImpl:async()=>new Response(JSON.stringify(result))});await assert.rejects(t.generate({kind:'advice'},{student:student()}));assert.equal(t.active,0);
 }
});

test('Le fait du conseil est repris des données, le modèle ne rédige que la méthode de travail',async()=>{
 const s=student();let payload;
 const tutor=new LocalTutor({fetchImpl:async(url,options)=>{payload=JSON.parse(options.body);return new Response(JSON.stringify({message:{content:JSON.stringify({title:'Reprendre la correction',action:'Choisis une question de ta dernière copie et refais-la sans regarder la solution.'})},done_reason:'stop'}));}});
 const result=await tutor.generate({kind:'advice'},{student:s});assert.match(result.body,/12,28\/20/);assert.ok(!JSON.stringify(payload.messages).includes('absenceHalfDays'));assert.match(result.body,/Choisis une question/);
});
test('Une resynchronisation retire les élèves sortis du périmètre autorisé',async()=>{
 const f=makeFixtureFetch({teacher:true});let narrowed=false;
 const c=new EcoleDirecteConnector({now:testNow,fetchImpl:async(url,options)=>{const r=await f.fetchImpl(url,options);if(narrowed&&/\/(classes|groupes)\//.test(new URL(url).pathname)){const body=await r.json();body.data.eleves=body.data.eleves.filter(s=>s.id===42);return new Response(JSON.stringify(body));}return r;}});
 await c.login('prof','fictif');await c.sync();assert.ok(c.authorizedStudents.has('ed-43'));narrowed=true;await c.sync();assert.equal(c.authorizedStudents.has('ed-43'),false);await assert.rejects(c.planner('ed-43','2026-10-19'),{status:403});
});
