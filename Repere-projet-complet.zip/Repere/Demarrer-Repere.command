#!/bin/bash
cd -- "$(dirname -- "$0")" || exit 1
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
if ! command -v node >/dev/null 2>&1; then
  echo 'Installez Node.js 22 ou plus récent depuis https://nodejs.org/ puis relancez ce fichier.'
  read -r -p 'Appuyez sur Entrée pour fermer. '
  exit 1
fi
node start.mjs
repere_result=$?
if [ "$repere_result" -ne 0 ]; then read -r -p 'Appuyez sur Entrée pour fermer. '; fi
exit "$repere_result"
