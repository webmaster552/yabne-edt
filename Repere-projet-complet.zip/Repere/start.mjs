import {spawn} from 'node:child_process';

if(Number(process.versions.node.split('.')[0])<22){
 console.error('Repère nécessite Node.js 22 ou plus récent. Installation : https://nodejs.org/');
 process.exit(1);
}
const {createAppServer}=await import('./server.mjs');
const port=Number(process.env.REPERE_PORT??4173);
if(!Number.isInteger(port)||(port!==0&&(port<1024||port>65535))){
 console.error('REPERE_PORT doit être un port entre 1024 et 65535.');process.exit(1);
}
const server=createAppServer();
server.on('error',error=>{
 console.error(error.code==='EADDRINUSE'?`Le port ${port} est déjà utilisé. Si Repère est déjà lancé, ouvrez http://127.0.0.1:${port}/ ; sinon fermez le programme qui utilise ce port.`:'Impossible de démarrer le serveur local : '+error.message);
 process.exitCode=1;
});
server.listen(port,'127.0.0.1',()=>{
 const url=`http://127.0.0.1:${server.address().port}/`;
 console.log('\nRepère est prêt : '+url+'\n');
 console.log('Gardez cette fenêtre ouverte. Ctrl+C arrête Repère.');
 console.log('Les conseils et la lecture des photos nécessitent Ollama et ses modèles (voir LISEZ-MOI.txt).');
 if(!process.argv.includes('--no-open')){
  const command=process.platform==='darwin'?['open',[url]]:process.platform==='win32'?['rundll32.exe',['url.dll,FileProtocolHandler',url]]:['xdg-open',[url]];
  const child=spawn(command[0],command[1],{stdio:'ignore',detached:true});
  child.on('error',()=>console.log('Ouvrez cette adresse manuellement dans votre navigateur : '+url));child.unref();
 }
});
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>{server.closeAllConnections();server.close(()=>process.exit(0));});
