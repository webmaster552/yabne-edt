import {demoPlanner,studyWeek} from './dist/study.mjs';
import {homeworkKey} from './dist/insights.mjs';
import {LocalTutor} from './server/tutor.mjs';
import {createDemoStudents} from './dist/engine.mjs';
import http from 'node:http';
import {readFile} from 'node:fs/promises';
import {resolve,extname,sep} from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomBytes} from 'node:crypto';
import {EcoleDirecteConnector,ConnectorError,API_VERSION} from './server/connector.mjs';
const root=resolve(fileURLToPath(new URL('./dist',import.meta.url)));
export function createAppServer({connectorFactory=()=>new EcoleDirecteConnector(),now=()=>Date.now(),tutor=new LocalTutor()}={}){
 const sessions=new Map(),attempts=[],tutorJobs=new Map();
 const expire=s=>{s.connector.clear();s.sync=null;for(const [id,j] of tutorJobs)if(j.owner===s){j.abort.abort();tutorJobs.delete(id);}};
 const publicSync=s=>s.sync?{status:s.sync.status,progress:s.sync.progress,account:s.connector.publicAccount(),...(s.sync.status==='complete'?{payload:s.sync.payload}:{}),...(s.sync.status==='error'?{failure:s.sync.failure}:{})}:{status:'idle',account:s.connector.publicAccount()};
 const cleanup=()=>{for(const [id,j] of tutorJobs)if(j.expires<now()){j.abort.abort();tutorJobs.delete(id);}for(const [key,s] of sessions)if(s.expires<now()){expire(s);sessions.delete(key);}};
 const timer=setInterval(cleanup,60000);timer.unref();
 const server=http.createServer(async(req,res)=>{
  res.setHeader('Cache-Control','no-store');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('X-Frame-Options','DENY');
  res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; font-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'");
  const port=server.address()?.port;
  if(![`127.0.0.1:${port}`,`localhost:${port}`].includes(req.headers.host)){res.writeHead(403);res.end();return;}
  const url=new URL(req.url,`http://${req.headers.host}`);
  const json=(status,data)=>{res.writeHead(status,{'Content-Type':'application/json;charset=utf-8'});res.end(JSON.stringify(data));};
  const sid=(req.headers.cookie||'').split(';').map(s=>s.trim()).find(s=>s.startsWith('repere_session='))?.slice(15);
  cleanup();let session=sessions.get(sid);
  const ensureActive=()=>{if(!session||sessions.get(sid)!==session||session.expires<now())throw new ConnectorError('SESSION_CLOSED','La session a été fermée ou a expiré.',401);};
  const refreshCookie=()=>res.setHeader('Set-Cookie',`repere_session=${sid}; HttpOnly; SameSite=Strict; Path=/api; Max-Age=1800`);
  const remove=()=>{if(session){expire(session);sessions.delete(sid);}session=null;res.setHeader('Set-Cookie','repere_session=; HttpOnly; SameSite=Strict; Path=/api; Max-Age=0');};
  try{
   if(url.pathname.startsWith('/api/')){
    const readOnly=req.method==='GET';
    if(!readOnly){
     if(req.method!=='POST'||req.headers['x-repere-request']!=='1'||req.headers['content-type']?.split(';')[0]!=='application/json'||req.headers.origin!==`http://${req.headers.host}`)throw new ConnectorError('ORIGIN_REJECTED','Requête non autorisée depuis cette page.',403);
    }else if(req.headers['sec-fetch-site']&& !['same-origin','none'].includes(req.headers['sec-fetch-site']))throw new ConnectorError('ORIGIN_REJECTED','Origine non autorisée.',403);
    let input={};
    if(!readOnly){let body='';for await(const chunk of req){body+=chunk;if(body.length>(url.pathname==='/api/tutor'?4_500_000:12000))throw new ConnectorError('BODY_TOO_LARGE','Requête trop volumineuse.',413);}try{input=JSON.parse(body);}catch{throw new ConnectorError('INVALID_JSON','Requête invalide.',400);}if(!input||Array.isArray(input)||typeof input!=='object')throw new ConnectorError('INVALID_BODY','Requête invalide.',400);}
    if(url.pathname==='/api/session'&&readOnly){json(200,{available:true,status:session?.connector.account?'authenticated':session?.connector.pending?'challenge':'disconnected',account:session?.connector.publicAccount()||null,challenge:session?.connector.publicChallenge?.()||null,syncStatus:session?.sync?.status||'idle',version:API_VERSION});return;}
    if(url.pathname==='/api/tutor/status'&&readOnly){json(200,await tutor.status());return;}
    if(url.pathname==='/api/tutor'&&req.method==='POST'){
     let student,planner,owner;
     if(input.scope==='teacher'){
      if(input.demo===true){owner='demo';}else{ensureActive();if(session.connector.publicAccount()?.role!=='teacher')throw new ConnectorError('TEACHER_REQUIRED','Cet espace est réservé aux professeurs.',403);owner=session;}
     }
     else if(input.demo===true){student=createDemoStudents().find(s=>s.id===input.studentId);if(student)planner=demoPlanner(student,studyWeek(new Date(now())));owner='demo';}
     else {ensureActive();student=session.sync?.payload?.students.find(s=>s.id===input.studentId);owner=session;const plans=[...(session.connector.planners||new Map()).values()].filter(p=>p.studentId===input.studentId).sort((a,b)=>a.loadedAt-b.loadedAt);if(plans.length){const latest=plans.at(-1),merge=field=>[...new Map(plans.flatMap(p=>p[field]||[]).map(x=>[homeworkKey(x),x])).values()];planner={...latest,homework:latest.homework,lessons:merge('lessons')};}}
     if(input.scope!=='teacher'&&!student)throw new ConnectorError('FORBIDDEN_STUDENT','Ce dossier n’est pas accessible depuis votre compte.',403);
     if([...tutorJobs.values()].some(j=>j.status==='running'))throw new ConnectorError('TUTOR_BUSY','Une préparation est en cours. Attends sa fin puis réessaie.',409);
     const id=randomBytes(20).toString('hex'),job={owner,abort:new AbortController(),status:'running',expires:now()+600000};tutorJobs.set(id,job);
     if(session){session.expires=now()+1800000;refreshCookie();}
     Promise.resolve().then(()=>tutor.generate(input,{student,planner,signal:job.abort.signal})).then(answer=>{if(!job.abort.signal.aborted){job.answer=answer;job.status='complete';}}).catch(error=>{job.status='error';job.message=error instanceof ConnectorError?error.message:'La préparation a échoué. Réessaie.';});
     json(202,{id,status:job.status});return;
    }
    if(url.pathname.startsWith('/api/tutor/jobs/')){
     const id=url.pathname.slice('/api/tutor/jobs/'.length),job=tutorJobs.get(id);
     if(!job||job.owner!=='demo'&&job.owner!==session)throw new ConnectorError('NOT_FOUND','Préparation introuvable.',404);
     if(req.method==='POST'){job.abort.abort();tutorJobs.delete(id);json(200,{status:'cancelled'});return;}
     json(200,{status:job.status,...(job.status==='complete'?{answer:job.answer}:{}),...(job.status==='error'?{message:job.message}:{})});return;
    }
    if(url.pathname==='/api/login'&&req.method==='POST'){
     const {username,password}=input;
     if(typeof username!=='string'||!username.trim()||username.length>256||typeof password!=='string'||!password||password.length>512)throw new ConnectorError('CREDENTIALS_REQUIRED','Renseignez votre identifiant et votre mot de passe.',400);
     while(attempts[0]<now()-600000)attempts.shift();if(attempts.length>=5)throw new ConnectorError('RATE_LIMIT','Cinq tentatives ont déjà été effectuées. Attendez dix minutes avant de réessayer.',429);attempts.push(now());
     remove();const newId=randomBytes(32).toString('hex');session={connector:connectorFactory(),expires:now()+300000,busy:true};sessions.set(newId,session);
     try{const result=await session.connector.login(username.trim(),password);if(sessions.get(newId)!==session)throw new ConnectorError('SESSION_CLOSED','La session a expiré.',401);session.expires=now()+(result.status==='authenticated'?1800000:300000);res.setHeader('Set-Cookie',`repere_session=${newId}; HttpOnly; SameSite=Strict; Path=/api; Max-Age=1800`);json(200,result);}
     catch(e){expire(session);sessions.delete(newId);throw e;}finally{session.busy=false;}
     return;
    }
    if(url.pathname==='/api/logout'&&req.method==='POST'){remove();json(200,{status:'disconnected'});return;}
    if(!session)throw new ConnectorError('NOT_CONNECTED','Session absente ou expirée. Connectez-vous.',401);
    if(url.pathname==='/api/challenge'&&req.method==='POST'){
     if(session.busy)throw new ConnectorError('BUSY','Une requête est déjà en cours.',409);session.busy=true;
     try{const result=await session.connector.challenge(input);ensureActive();refreshCookie();session.expires=now()+(result.status==='authenticated'?1800000:300000);json(200,result);}finally{session.busy=false;}return;
    }
    if(!session.connector.account)throw new ConnectorError('AUTH_REQUIRED','Terminez la vérification de connexion.',401);
    if(url.pathname==='/api/planner'&&req.method==='POST'){
     if(session.busy)throw new ConnectorError('BUSY','Le dossier est encore en cours de chargement.',409);
     session.busy=true;
     try{const data=await session.connector.planner(input.studentId,input.start,{force:input.refresh===true});ensureActive();session.expires=now()+1800000;refreshCookie();json(200,data);}finally{session.busy=false;}return;
    }
    if(url.pathname==='/api/sync'&&readOnly){json(200,publicSync(session));return;}
    if(url.pathname==='/api/sync'&&req.method==='POST'){
     if(input.background===true){
      if(session.sync?.status==='running'){json(202,publicSync(session));return;}
      if(session.busy)throw new ConnectorError('BUSY','Une vérification est encore en cours.',409);
      const current=session,job={status:'running',progress:{phase:'starting',completed:0,total:null}};
      current.sync=job;current.busy=true;current.expires=now()+1800000;refreshCookie();
      // Only one upstream import per session. Reopening the page resumes observation.
      Promise.resolve().then(()=>current.connector.sync(progress=>{ensureActive();job.progress=progress;})).then(payload=>{
       ensureActive();job.payload=payload;job.status='complete';current.expires=now()+1800000;
      }).catch(error=>{
       if(sessions.get(sid)!==current||current.sync!==job)return;
       job.status='error';job.failure={status:error instanceof ConnectorError?error.status:500,message:error instanceof ConnectorError?error.message:'Le chargement a échoué. Réessayez depuis votre espace.',code:error instanceof ConnectorError?error.code:'SYNC_FAILED'};
      }).finally(()=>{current.busy=false;});
      json(202,publicSync(current));return;
     }
     if(session.busy)throw new ConnectorError('BUSY','Une synchronisation est déjà en cours.',409);session.busy=true;
     try{const data=await session.connector.sync();ensureActive();session.sync={status:'complete',payload:data};refreshCookie();session.expires=now()+1800000;json(200,data);}finally{session.busy=false;}return;
    }
    if(url.pathname.startsWith('/api/photo/')&&readOnly){const id=decodeURIComponent(url.pathname.slice(11));if(!/^ed-\d+(?:-\d+)?$/.test(id))throw new ConnectorError('NOT_FOUND','Photo indisponible.',404);const photo=await session.connector.photo(id);ensureActive();res.writeHead(200,{'Content-Type':photo.type});res.end(photo.bytes);return;}
    throw new ConnectorError('NOT_FOUND','Route inexistante.',404);
   }
   if(!['GET','HEAD'].includes(req.method)){json(405,{message:'Méthode non autorisée.'});return;}
   let requested;try{requested=decodeURIComponent(url.pathname);}catch{throw new ConnectorError('NOT_FOUND','Page inexistante.',404);}
   const file=resolve(root,'.'+(requested==='/'?'/index.html':requested));
   if(!file.startsWith(root+sep)||requested.split('/').some(p=>p.startsWith('.'))){json(404,{message:'Page inexistante.'});return;}
   const content=await readFile(file);
   const types={'.html':'text/html;charset=utf-8','.css':'text/css;charset=utf-8','.js':'text/javascript;charset=utf-8','.mjs':'text/javascript;charset=utf-8','.svg':'image/svg+xml','.png':'image/png'};
   if(!types[extname(file)]){json(404,{message:'Page inexistante.'});return;}
   res.writeHead(200,{'Content-Type':types[extname(file)]});res.end(req.method==='HEAD'?undefined:content);
  }catch(error){if(res.headersSent){res.end();return;}const known=error instanceof ConnectorError;json(known?error.status:error.code==='ENOENT'?404:500,{error:known?error.code:'SERVER_ERROR',message:known?error.message:'Impossible de terminer la requête. Aucune information de connexion n’a été journalisée.'});}
 });
 server.on('close',()=>{clearInterval(timer);for(const s of sessions.values())expire(s);sessions.clear();for(const j of tutorJobs.values())j.abort.abort();tutorJobs.clear();});
 server.requestTimeout=300000;server.headersTimeout=15000;
 return server;
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const port=Number(process.env.REPERE_PORT||4173);if(!Number.isInteger(port)||port<1024||port>65535)throw new Error('Port local invalide.');
 const server=createAppServer();
 server.listen(port,'127.0.0.1',()=>console.log(`Repère : http://127.0.0.1:${port}/#connection — serveur local, identifiants et jetons conservés en mémoire.`));
 for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>{server.closeAllConnections();server.close(()=>process.exit(0));});
}
