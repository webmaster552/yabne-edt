"""Package the demo as one HTML file; no server or dependencies required."""
from pathlib import Path
import base64
import re
import sys

root = Path(__file__).resolve().parent
out = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else root / 'Repere.html'
dist = root / 'dist'
html = (dist / 'index.html').read_text()
css = (dist / 'styles.css').read_text()
connection = re.sub(r'^export ', '', (dist / 'connection.mjs').read_text(), flags=re.MULTILINE)
engine = re.sub(r'^export ', '', (dist / 'engine.mjs').read_text(), flags=re.MULTILINE)
insights = re.sub(r'^import .*?;\n|^export ', '', (dist / 'insights.mjs').read_text(), flags=re.MULTILINE)
coach = re.sub(r'^import .*?;\n|^export ', '', (dist / 'coach.mjs').read_text(), flags=re.MULTILINE)
progress = re.sub(r'^import .*?;\n|^export ', '', (dist / 'progress.mjs').read_text(), flags=re.MULTILINE)
tutor_client = re.sub(r'^import .*?;\n|^export ', '', (dist / 'tutor-client.mjs').read_text(), flags=re.MULTILINE)
study = re.sub(r'^import .*?;\n|^export ', '', (dist / 'study.mjs').read_text(), flags=re.MULTILINE)
extras = '\n'.join(re.sub(r'^import .*?;\n|^export ', '', (dist / file).read_text(), flags=re.MULTILINE) for file in ['teacher-view.mjs'])
app = re.sub(r'^import .*?;\n', '', (dist / 'app.js').read_text(), flags=re.MULTILINE)
for file, mime in [('portraits-fictifs.png', 'image/png'), ('favicon.svg', 'image/svg+xml')]:
    data = f'data:{mime};base64,' + base64.b64encode((dist / 'assets' / file).read_bytes()).decode('ascii')
    css = css.replace(f'assets/{file}', data)
    html = html.replace(f'assets/{file}', data)
    app = app.replace(f'assets/{file}', data)
# The standalone file is fully offline; use the same system fallbacks for text.
css = re.sub(r"@import url\([^\n]+\);\n", '', css, count=1)
html = html.replace('<link rel="stylesheet" href="styles.css">', '<style>\n' + css + '\n</style>')
html = html.replace('<script type="module" src="app.js"></script>', '<script type="module">\n' + connection + '\n' + engine + '\n' + insights + '\n' + coach + '\n' + progress + '\n' + tutor_client + '\n' + study + '\n' + extras + '\n' + app + '\n</script>')
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(html)
print(f'Standalone HTML: {out.name} ({out.stat().st_size:,} bytes)')
