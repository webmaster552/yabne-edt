// Only display metadata; never expose the upstream account or authentication fields.
const firstText=(...values)=>values.find(v=>typeof v==='string'&&v.trim())?.trim()||'';
export function establishmentName(...sources){
 for(const s of sources){if(!s||typeof s!=='object')continue;const name=firstText(s.nomEtablissement,s.profile?.nomEtablissement,s.etablissement?.nom,s.etablissement?.libelle);if(name)return name.slice(0,200);}
 return '';
}
export function identityOf(raw){
 return {id:raw.id,prenom:firstText(raw.prenom),nom:firstText(raw.nom),photo:firstText(raw.photo,raw.profile?.photo),classe:raw.classe||raw.profile?.classe,classeLibelle:firstText(raw.classeLibelle,raw.profile?.classeLibelle),classLabel:firstText(raw.classLabel),nomEtablissement:establishmentName(raw)};
}
export function photoAddress(value){
 if(typeof value!=='string'||!value.trim())return null;
 try{
  // Relative links have a fixed origin. Never accept a host supplied by the browser.
  const url=new URL(value.trim(), 'https://api.ecoledirecte.com');
  if(url.protocol!=='https:'||url.username||url.password||url.port||(url.hostname!=='ecoledirecte.com'&&!url.hostname.endsWith('.ecoledirecte.com')))return null;
  return url.href;
 }catch{return null;}
}
