import {durationHalfDays,attendanceDetails} from './attendance.mjs';
const DAY=86400000;
export function number(value){
 if(typeof value==='number')return Number.isFinite(value)?value:null;
 if(typeof value!=='string'||!/^\s*-?\d+(?:[.,]\d+)?\s*$/.test(value))return null;
 return Number(value.trim().replace(',','.'));
}
export function dateOnly(value){
 if(typeof value!=='string'||!/^\d{4}-\d{2}-\d{2}(?:$|[ T])/.test(value))return null;
 const d=value.slice(0,10);const t=Date.parse(d+'T12:00:00Z');
 return Number.isFinite(t)&&new Date(t).toISOString().slice(0,10)===d?d:null;
}
export function windows(now=new Date()){
 const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Paris',year:'numeric',month:'2-digit',day:'2-digit'}).format(now);
 const end=new Date(today+'T12:00:00Z').getTime();
 const day=n=>new Date(end+n*DAY).toISOString().slice(0,10);
 return {previousStart:day(-55),previousEnd:day(-28),recentStart:day(-27),recentEnd:day(0)};
}
const bool=v=>v===true||v===1||v==='1'||v==='true'?true:v===false||v===0||v==='0'||v==='false'?false:null;
export function normalizeGrades(data,periods){
 if(!Array.isArray(data?.notes))return {grades:[],warnings:['Notes non transmises par ÉcoleDirecte.']};
 const grades=[],seen=new Set();
 for(const [index,g] of data.notes.entries()){
  const id=String(g.id??`note-${index}`);if(seen.has(id))continue;seen.add(id);
  const value=number(g.valeur),outOf=number(g.noteSur),weight=number(g.coef),date=dateOnly(g.date)||'';
  const period=date>=periods.recentStart&&date<=periods.recentEnd?'recent':date>=periods.previousStart&&date<=periods.previousEnd?'previous':'other';
  grades.push({id,subject:String(g.libelleMatiere||g.codeMatiere||'Matière non précisée').slice(0,150),subjectCode:String(g.codeMatiere||''),title:String(g.devoir||'').slice(0,300),reportId:String(g.codePeriode||''),value,outOf,weight,date,period,displayValue:String(g.valeur??'').slice(0,40),significant:!bool(g.nonSignificatif)});
 }
 return {grades,warnings:[]};
}
export function halfDays(item){return durationHalfDays(item,number);}
export function normalizeAttendance(data,periods){
 const {absenceHalfDays,justifiedHalfDays,lates,warnings}=attendanceDetails(data,periods,{dateOnly,number});
 return {absenceHalfDays,justifiedHalfDays,lates,warnings};
}
export function normalizePeriods(data){
 const avg=v=>{const n=number(v);return n!==null&&n>=0&&n<=20?n:null;};
 return (Array.isArray(data?.periodes)?data.periodes:[]).filter(p=>p&&typeof p==='object').map(p=>({id:String(p.idPeriode||p.codePeriode||p.periode||''),label:String(p.periode||'Période').slice(0,100),start:dateOnly(p.dateDebut),end:dateOnly(p.dateFin),average:avg(p.ensembleMatieres?.moyenneGenerale),annual:bool(p.annuel)===true,subjects:(Array.isArray(p.ensembleMatieres?.disciplines)?p.ensembleMatieres.disciplines:[]).map(d=>({subject:String(d.discipline||d.libelleMatiere||d.codeMatiere||'Matière').slice(0,150),code:String(d.codeMatiere||''),average:avg(d.moyenne),classAverage:avg(d.moyenneClasse),coefficient:number(d.coef),comment:String(d.appreciation||'').slice(0,1500)}))}));
}
export function normalizedStudent(raw,notes,schoolLife,periods){
 const g=normalizeGrades(notes,periods),a=attendanceDetails(schoolLife,periods,{dateOnly,number});
 return {id:`ed-${raw.id}`,source:'ecoledirecte',firstName:String(raw.prenom||'Élève').slice(0,100),lastName:String(raw.nom||'').slice(0,100),className:String(raw.classe?.libelle||raw.classeLibelle||raw.classLabel||'Classe non précisée').slice(0,100),grades:g.grades,reportPeriods:normalizePeriods(notes),attendance:{absenceHalfDays:a.absenceHalfDays,justifiedHalfDays:a.justifiedHalfDays,lates:a.lates,absenceEvents:a.absenceEvents,justifiedEvents:a.justifiedEvents,events:a.events},weekly:[],warnings:[...g.warnings,...a.warnings]};
}
